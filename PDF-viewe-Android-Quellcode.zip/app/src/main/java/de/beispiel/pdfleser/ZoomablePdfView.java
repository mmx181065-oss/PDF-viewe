package de.beispiel.pdfleser;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

/** Renders one PDF page with pinch-to-zoom, dragging and double-tap to reset. */
public final class ZoomablePdfView extends View {
    private final Matrix transform = new Matrix();
    private final Paint bitmapPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint placeholderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final ScaleGestureDetector scaleDetector;
    private final GestureDetector tapDetector;
    private Bitmap bitmap;
    private float fitScale = 1f;
    private float currentScale = 1f;
    private float lastX;
    private float lastY;

    public ZoomablePdfView(Context context) {
        super(context);
        scaleDetector = new ScaleGestureDetector(context,
            new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                @Override
                public boolean onScale(ScaleGestureDetector detector) {
                    if (bitmap == null) return false;
                    float minimum = fitScale;
                    float maximum = fitScale * 5f;
                    float intended = currentScale * detector.getScaleFactor();
                    float bounded = Math.max(minimum, Math.min(maximum, intended));
                    float scaleBy = bounded / currentScale;
                    transform.postScale(scaleBy, scaleBy,
                        detector.getFocusX(), detector.getFocusY());
                    currentScale = bounded;
                    clampTranslation();
                    invalidate();
                    return true;
                }
            });
        tapDetector = new GestureDetector(context,
            new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onDown(MotionEvent event) { return true; }
                @Override
                public boolean onDoubleTap(MotionEvent event) {
                    if (bitmap == null) return false;
                    if (currentScale > fitScale * 1.1f) {
                        resetZoom();
                    } else {
                        float factor = 2.2f;
                        transform.postScale(factor, factor, event.getX(), event.getY());
                        currentScale *= factor;
                        clampTranslation();
                        invalidate();
                    }
                    return true;
                }
            });
        setContentDescription("PDF-Seite. Mit zwei Fingern zoomen, mit einem Finger verschieben.");
    }

    public void setBitmap(Bitmap newBitmap) {
        Bitmap previous = bitmap;
        bitmap = newBitmap;
        resetZoom();
        if (previous != null && previous != newBitmap && !previous.isRecycled()) {
            previous.recycle();
        }
    }

    public void clear() {
        setBitmap(null);
    }

    public void resetZoom() {
        transform.reset();
        if (bitmap == null || getWidth() <= 0 || getHeight() <= 0) {
            fitScale = 1f;
            currentScale = 1f;
            invalidate();
            return;
        }
        fitScale = Math.min((float) getWidth() / bitmap.getWidth(),
                            (float) getHeight() / bitmap.getHeight());
        currentScale = fitScale;
        transform.postScale(fitScale, fitScale);
        transform.postTranslate(
            (getWidth() - bitmap.getWidth() * fitScale) / 2f,
            (getHeight() - bitmap.getHeight() * fitScale) / 2f);
        invalidate();
    }

    @Override
    protected void onSizeChanged(int width, int height, int oldWidth, int oldHeight) {
        super.onSizeChanged(width, height, oldWidth, oldHeight);
        resetZoom();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawColor(Color.rgb(224, 229, 237));
        if (bitmap != null && !bitmap.isRecycled()) {
            canvas.drawBitmap(bitmap, transform, bitmapPaint);
        } else {
            placeholderPaint.setColor(Color.rgb(72, 88, 108));
            placeholderPaint.setTextAlign(Paint.Align.CENTER);
            placeholderPaint.setTextSize(sp(19));
            canvas.drawText("PDF-Datei öffnen", getWidth() / 2f,
                getHeight() / 2f - sp(9), placeholderPaint);
            placeholderPaint.setTextSize(sp(13));
            canvas.drawText("Zum Start oben auf Öffnen tippen",
                getWidth() / 2f, getHeight() / 2f + sp(22), placeholderPaint);
        }
    }

    private float sp(float value) {
        return value * getResources().getDisplayMetrics().scaledDensity;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        scaleDetector.onTouchEvent(event);
        tapDetector.onTouchEvent(event);
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                lastX = event.getX();
                lastY = event.getY();
                return true;
            case MotionEvent.ACTION_POINTER_DOWN:
                lastX = event.getX();
                lastY = event.getY();
                return true;
            case MotionEvent.ACTION_MOVE:
                if (bitmap != null && event.getPointerCount() == 1
                    && !scaleDetector.isInProgress() && currentScale > fitScale * 1.001f) {
                    float dx = event.getX() - lastX;
                    float dy = event.getY() - lastY;
                    transform.postTranslate(dx, dy);
                    clampTranslation();
                    invalidate();
                }
                lastX = event.getX();
                lastY = event.getY();
                return true;
            case MotionEvent.ACTION_UP:
                performClick();
                return true;
            default:
                return true;
        }
    }

    @Override
    public boolean performClick() {
        super.performClick();
        return true;
    }

    private void clampTranslation() {
        if (bitmap == null) return;
        RectF frame = new RectF(0, 0, bitmap.getWidth(), bitmap.getHeight());
        transform.mapRect(frame);
        float dx = 0;
        float dy = 0;
        if (frame.width() <= getWidth()) {
            dx = getWidth() / 2f - frame.centerX();
        } else if (frame.left > 0) {
            dx = -frame.left;
        } else if (frame.right < getWidth()) {
            dx = getWidth() - frame.right;
        }
        if (frame.height() <= getHeight()) {
            dy = getHeight() / 2f - frame.centerY();
        } else if (frame.top > 0) {
            dy = -frame.top;
        } else if (frame.bottom < getHeight()) {
            dy = getHeight() - frame.bottom;
        }
        transform.postTranslate(dx, dy);
    }
}
