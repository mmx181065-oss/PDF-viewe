package de.beispiel.pdfleser;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

public final class MainActivity extends Activity {
    private static final int REQUEST_OPEN_PDF = 200;
    private static final long MAX_CACHED_PDF_BYTES = 250L * 1024 * 1024;
    private static final int MAX_BITMAP_SIDE = 4096;
    private static final long MAX_BITMAP_PIXELS = 12_000_000L;

    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final AtomicInteger documentVersion = new AtomicInteger();
    private final AtomicInteger renderVersion = new AtomicInteger();

    // The following fields are only accessed by the single worker thread.
    private PdfRenderer renderer;
    private File temporaryPdf;

    // The following fields are only accessed by the main/UI thread.
    private ZoomablePdfView pdfView;
    private ProgressBar progress;
    private TextView fileName;
    private TextView pageNumber;
    private Button previousButton;
    private Button nextButton;
    private Button fitButton;
    private Button shareButton;
    private Uri currentUri;
    private int currentPage;
    private int pageCount;
    private volatile boolean destroyed;

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
        SharedPreferences prefs = getPreferences(MODE_PRIVATE);
        String last = prefs.getString("lastUri", null);
        if (last != null) {
            try {
                openPdf(Uri.parse(last), prefs.getInt("lastPage", 0));
            } catch (RuntimeException ignored) {
                prefs.edit().remove("lastUri").apply();
            }
        }
    }

    private void buildUi() {
        int navy = Color.rgb(20, 38, 61);
        int white = Color.WHITE;
        int gray = Color.rgb(94, 107, 124);
        int blue = Color.rgb(11, 107, 203);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(245, 247, 250));
        setContentView(root);

        // Android 15+ uses edge-to-edge system bars for apps targeting API 35.
        if (Build.VERSION.SDK_INT >= 30) {
            root.setOnApplyWindowInsetsListener((view, insets) -> {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                view.setPadding(bars.left, bars.top, bars.right, bars.bottom);
                return insets;
            });
        } else {
            root.setFitsSystemWindows(true);
        }

        LinearLayout toolbar = new LinearLayout(this);
        toolbar.setPadding(dp(16), dp(10), dp(12), dp(10));
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setOrientation(LinearLayout.HORIZONTAL);
        toolbar.setBackgroundColor(navy);
        root.addView(toolbar, new LinearLayout.LayoutParams(-1, dp(64)));

        TextView title = new TextView(this);
        title.setText("PDF-Leser");
        title.setTextColor(white);
        title.setTextSize(21);
        title.setTypeface(null, 1);
        toolbar.addView(title, new LinearLayout.LayoutParams(0, -2, 1));

        shareButton = createButton("Teilen", white, navy);
        shareButton.setOnClickListener(view -> sharePdf());
        toolbar.addView(shareButton, new LinearLayout.LayoutParams(dp(76), dp(42)));

        Button openButton = createButton("Öffnen", blue, white);
        LinearLayout.LayoutParams openParams = new LinearLayout.LayoutParams(dp(88), dp(42));
        openParams.leftMargin = dp(8);
        toolbar.addView(openButton, openParams);
        openButton.setOnClickListener(view -> choosePdf());

        fileName = new TextView(this);
        fileName.setText("Noch keine PDF-Datei ausgewählt");
        fileName.setTextColor(gray);
        fileName.setSingleLine(true);
        fileName.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        fileName.setGravity(Gravity.CENTER_VERTICAL);
        fileName.setTextSize(14);
        fileName.setPadding(dp(16), 0, dp(16), 0);
        root.addView(fileName, new LinearLayout.LayoutParams(-1, dp(42)));

        FrameLayout viewport = new FrameLayout(this);
        root.addView(viewport, new LinearLayout.LayoutParams(-1, 0, 1));
        pdfView = new ZoomablePdfView(this);
        viewport.addView(pdfView, new FrameLayout.LayoutParams(-1, -1));

        progress = new ProgressBar(this);
        progress.setIndeterminateTintList(ColorStateList.valueOf(blue));
        FrameLayout.LayoutParams busyParams = new FrameLayout.LayoutParams(dp(48), dp(48), Gravity.CENTER);
        viewport.addView(progress, busyParams);
        progress.setVisibility(View.GONE);

        LinearLayout navigation = new LinearLayout(this);
        navigation.setBackgroundColor(white);
        navigation.setPadding(dp(10), dp(9), dp(10), dp(9));
        navigation.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(navigation, new LinearLayout.LayoutParams(-1, dp(72)));

        previousButton = createButton("‹", navy, white);
        previousButton.setTextSize(27);
        previousButton.setContentDescription("Vorherige Seite");
        navigation.addView(previousButton, new LinearLayout.LayoutParams(dp(55), dp(48)));
        previousButton.setOnClickListener(view -> goToPage(currentPage - 1));

        pageNumber = new TextView(this);
        pageNumber.setText("– / –");
        pageNumber.setTextSize(16);
        pageNumber.setTypeface(null, 1);
        pageNumber.setGravity(Gravity.CENTER);
        pageNumber.setTextColor(navy);
        pageNumber.setContentDescription("Seitenzahl, antippen für Seitensprung");
        pageNumber.setOnClickListener(view -> showPagePicker());
        navigation.addView(pageNumber, new LinearLayout.LayoutParams(0, -1, 1));

        nextButton = createButton("›", navy, white);
        nextButton.setTextSize(27);
        nextButton.setContentDescription("Nächste Seite");
        navigation.addView(nextButton, new LinearLayout.LayoutParams(dp(55), dp(48)));
        nextButton.setOnClickListener(view -> goToPage(currentPage + 1));

        fitButton = createButton("Einpassen", blue, white);
        LinearLayout.LayoutParams fitParams = new LinearLayout.LayoutParams(dp(96), dp(48));
        fitParams.leftMargin = dp(9);
        navigation.addView(fitButton, fitParams);
        fitButton.setOnClickListener(view -> pdfView.resetZoom());

        updateControls();
    }

    private Button createButton(String caption, int background, int foreground) {
        Button b = new Button(this);
        b.setText(caption);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setTextColor(foreground);
        b.setPadding(dp(2), 0, dp(2), 0);
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(background);
        drawable.setCornerRadius(dp(10));
        b.setBackground(drawable);
        return b;
    }

    private int dp(float amount) {
        return Math.round(amount * getResources().getDisplayMetrics().density);
    }

    private void choosePdf() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/pdf");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, REQUEST_OPEN_PDF);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_OPEN_PDF || resultCode != RESULT_OK || data == null) {
            return;
        }
        Uri uri = data.getData();
        if (uri == null) return;
        try {
            getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (SecurityException ignored) {
            // Some document providers offer only temporary access.
        }
        openPdf(uri, 0);
    }

    private void openPdf(Uri uri, int savedPage) {
        currentUri = uri;
        currentPage = 0;
        pageCount = 0;
        int docId = documentVersion.incrementAndGet();
        renderVersion.incrementAndGet();
        fileName.setText(getDisplayName(uri));
        pdfView.clear();
        updateControls();
        showBusy(true);

        worker.execute(() -> {
            closeOnWorker();
            try {
                openOnWorker(uri);
                int pages = renderer.getPageCount();
                if (pages < 1) throw new IOException("Das Dokument enthält keine Seiten.");
                int initial = Math.max(0, Math.min(savedPage, pages - 1));
                ui.post(() -> {
                    if (destroyed || docId != documentVersion.get()) return;
                    currentPage = initial;
                    pageCount = pages;
                    saveReadingPosition();
                    updateControls();
                    renderCurrentPage();
                });
            } catch (Exception error) {
                closeOnWorker();
                ui.post(() -> {
                    if (destroyed || docId != documentVersion.get()) return;
                    showBusy(false);
                    pdfView.clear();
                    pageCount = 0;
                    updateControls();
                    getPreferences(MODE_PRIVATE).edit().remove("lastUri").apply();
                    Toast.makeText(this,
                        "PDF konnte nicht geöffnet werden. Möglicherweise ist sie passwortgeschützt oder beschädigt.",
                        Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    private void openOnWorker(Uri uri) throws IOException {
        ParcelFileDescriptor descriptor = null;
        try {
            descriptor = getContentResolver().openFileDescriptor(uri, "r");
            if (descriptor == null) throw new IOException("Keine Datei verfügbar.");
            try {
                renderer = new PdfRenderer(descriptor);
                descriptor = null; // PdfRenderer owns the file descriptor.
                return;
            } catch (IllegalArgumentException notSeekable) {
                descriptor.close();
                descriptor = null;
                // Some cloud document providers offer non-seekable streams.
                // Copying into the private cache makes such PDFs readable.
                File file = File.createTempFile("pdfreader-", ".pdf", getCacheDir());
                temporaryPdf = file;
                try (InputStream input = getContentResolver().openInputStream(uri);
                     FileOutputStream output = new FileOutputStream(file)) {
                    if (input == null) throw new IOException("Datei konnte nicht gelesen werden.");
                    byte[] buf = new byte[64 * 1024];
                    long total = 0;
                    int count;
                    while ((count = input.read(buf)) != -1) {
                        total += count;
                        if (total > MAX_CACHED_PDF_BYTES) {
                            throw new IOException("Die PDF ist für den temporären Cache zu groß.");
                        }
                        output.write(buf, 0, count);
                    }
                }
                descriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY);
                renderer = new PdfRenderer(descriptor);
                descriptor = null;
            }
        } finally {
            if (descriptor != null) descriptor.close();
        }
    }

    private void renderCurrentPage() {
        if (pageCount <= 0) return;
        final int docId = documentVersion.get();
        final int renderId = renderVersion.incrementAndGet();
        final int requestedPage = currentPage;
        final int viewWidth = Math.max(pdfView.getWidth(), getResources().getDisplayMetrics().widthPixels);
        showBusy(true);
        worker.execute(() -> {
            if (destroyed || docId != documentVersion.get() || renderId != renderVersion.get()) return;
            Bitmap bitmap = null;
            try (PdfRenderer.Page page = renderer.openPage(requestedPage)) {
                double desiredWidth = Math.max(800.0, viewWidth * 1.8);
                double desiredHeight = desiredWidth * page.getHeight() / page.getWidth();
                double factor = Math.min(1.0,
                    Math.min(MAX_BITMAP_SIDE / desiredWidth, MAX_BITMAP_SIDE / desiredHeight));
                factor = Math.min(factor,
                    Math.sqrt(MAX_BITMAP_PIXELS / (desiredWidth * desiredHeight)));
                int w = Math.max(1, (int) Math.round(desiredWidth * factor));
                int h = Math.max(1, (int) Math.round(desiredHeight * factor));
                bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                bitmap.eraseColor(Color.WHITE);
                page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                Bitmap finished = bitmap;
                ui.post(() -> {
                    if (destroyed || docId != documentVersion.get() || renderId != renderVersion.get()) {
                        finished.recycle();
                        return;
                    }
                    pdfView.setBitmap(finished);
                    showBusy(false);
                });
            } catch (Exception | OutOfMemoryError error) {
                if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
                ui.post(() -> {
                    if (destroyed || docId != documentVersion.get() || renderId != renderVersion.get()) return;
                    showBusy(false);
                    Toast.makeText(this, "Diese Seite konnte nicht angezeigt werden.", Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    private void goToPage(int index) {
        if (index < 0 || index >= pageCount || index == currentPage) return;
        currentPage = index;
        saveReadingPosition();
        updateControls();
        renderCurrentPage();
    }

    private void showPagePicker() {
        if (pageCount <= 0) return;
        EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER);
        input.setSingleLine(true);
        input.setText(String.valueOf(currentPage + 1));
        input.setSelectAllOnFocus(true);
        int padding = dp(18);
        LinearLayout wrapper = new LinearLayout(this);
        wrapper.setPadding(padding, dp(8), padding, 0);
        wrapper.addView(input, new LinearLayout.LayoutParams(-1, -2));
        new AlertDialog.Builder(this)
            .setTitle("Zu Seite springen (1–" + pageCount + ")")
            .setView(wrapper)
            .setNegativeButton("Abbrechen", null)
            .setPositiveButton("Öffnen", (dialog, which) -> {
                try {
                    goToPage(Integer.parseInt(input.getText().toString().trim()) - 1);
                } catch (NumberFormatException ignored) {
                    Toast.makeText(this, "Bitte eine gültige Seitenzahl eingeben.", Toast.LENGTH_SHORT).show();
                }
            })
            .show();
    }

    private void sharePdf() {
        if (currentUri == null || pageCount <= 0) return;
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("application/pdf");
        send.putExtra(Intent.EXTRA_STREAM, currentUri);
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(send, "PDF teilen"));
    }

    private void showBusy(boolean busy) {
        progress.setVisibility(busy ? View.VISIBLE : View.GONE);
    }

    private void updateControls() {
        boolean hasDocument = pageCount > 0;
        previousButton.setEnabled(hasDocument && currentPage > 0);
        nextButton.setEnabled(hasDocument && currentPage < pageCount - 1);
        fitButton.setEnabled(hasDocument);
        shareButton.setEnabled(hasDocument);
        previousButton.setAlpha(previousButton.isEnabled() ? 1f : 0.45f);
        nextButton.setAlpha(nextButton.isEnabled() ? 1f : 0.45f);
        fitButton.setAlpha(fitButton.isEnabled() ? 1f : 0.45f);
        shareButton.setAlpha(shareButton.isEnabled() ? 1f : 0.45f);
        pageNumber.setText(hasDocument ? (currentPage + 1) + " / " + pageCount : "– / –");
    }

    private void saveReadingPosition() {
        if (currentUri == null) return;
        getPreferences(MODE_PRIVATE).edit()
            .putString("lastUri", currentUri.toString())
            .putInt("lastPage", currentPage)
            .apply();
    }

    private String getDisplayName(Uri uri) {
        try (Cursor cursor = getContentResolver().query(uri,
            new String[] { OpenableColumns.DISPLAY_NAME }, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                String name = cursor.getString(0);
                if (name != null && !name.isEmpty()) return name;
            }
        } catch (Exception ignored) { }
        String tail = uri.getLastPathSegment();
        return tail == null ? "PDF-Dokument" : tail;
    }

    private void closeOnWorker() {
        if (renderer != null) {
            try { renderer.close(); } catch (Exception ignored) { }
            renderer = null;
        }
        if (temporaryPdf != null) {
            // The app never modifies the source PDF.
            if (temporaryPdf.exists()) temporaryPdf.delete();
            temporaryPdf = null;
        }
    }

    @Override
    protected void onDestroy() {
        destroyed = true;
        documentVersion.incrementAndGet();
        renderVersion.incrementAndGet();
        worker.execute(this::closeOnWorker);
        worker.shutdown();
        pdfView.clear();
        super.onDestroy();
    }
}
