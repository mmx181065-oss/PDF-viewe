# PDF-Leser für Android

Ein schlanker, nativer PDF-Reader als Android-Studio-Projekt (Java, ohne zusätzliche PDF-Bibliothek).

## Funktionen in Version 1.0

- PDF-Dateien vom Telefon über die Android-Dateiauswahl öffnen
- PDFs aus Android-Dateianbietern (z. B. einer eingebundenen Drive-App) auswählen
- Vorherige/nächste Seite und direkter Seitensprung durch Antippen der Seitenzahl
- Vergrößern mit zwei Fingern, verschieben und Doppeltippen zum Einpassen
- PDF über das Android-Teilen-Menü weitergeben
- Zuletzt geöffnete Datei und letzte Seite beim nächsten Start wiederherstellen, soweit die Dateiberechtigung weiterhin besteht
- Keine Internet-Berechtigung, kein Tracking, keine Änderungen am PDF-Original

Technik: Android `PdfRenderer`, `ACTION_OPEN_DOCUMENT` und private Cache-Datei nur dann, wenn der Dateianbieter keinen seekbaren Zugriff anbietet. Es werden keine Originaldateien bearbeitet. Temporäre PDF-Kopien sind auf 250 MiB begrenzt und werden beim Schließen/Wechsel des Dokuments entfernt.

## APK mit Android Studio erstellen

1. Android Studio auf einem Windows-, macOS- oder Linux-Rechner installieren.
2. Die ZIP-Datei entpacken und den Ordner `PDF-Leser-Android` in Android Studio über **File > Open** öffnen.
3. Bei Bedarf die Installation von Android SDK Platform 35 und die Gradle-Synchronisierung bestätigen. Internet ist beim ersten Build nötig, um die Android-Buildwerkzeuge zu laden.
4. **Build > Build Bundle(s) / APK(s) > Build APK(s)** wählen.
5. Danach liegt die Test-APK unter `app/build/outputs/apk/debug/app-debug.apk`.
6. Diese APK auf das Android-Smartphone übertragen und installieren. Android kann dafür eine Zustimmung zum Installieren von Apps aus dieser Quelle verlangen.

Alternativ kann die GitHub-Actions-Datei `.github/workflows/build-apk.yml` das APK nach dem Hochladen des Projekts in ein GitHub-Repository automatisch als Build-Artefakt erzeugen.

## Voraussetzungen

- Android 6.0 (API 23) oder neuer; Ziel-API 35
- Android Studio mit JDK 17 oder neuer
- Gradle 8.11.1 und Android Gradle Plugin 8.9.2
- Es werden keine zusätzlichen Laufzeitbibliotheken benötigt.

## Einschränkungen

- Version 1.0 zeigt PDF-Seiten an. Sie bietet **noch keine** Volltextsuche, OCR, Anmerkungen, Formularbearbeitung, PDF-Bearbeitung oder EPUB-Unterstützung.
- Passwortgeschützte PDFs sind noch nicht unterstützt.
- Ein Cloud-Dateianbieter kann einen vollständigen Download vor dem Anzeigen verlangen. Das ist **kein direktes PDF-Streaming**.
- Sehr große oder ungewöhnliche PDFs können mehr Speicher benötigen oder nicht angezeigt werden.
- Dieses Projekt wurde auf korrekte Dateistruktur und XML geprüft. Ein tatsächlicher Android-Build und Gerätetest waren in der Erstellungsumgebung mangels Android SDK nicht möglich.

## Datenschutz

Die App verwendet keine Internet-Berechtigung. Der Dateizugriff erfolgt über den System-Dateidialog; die ausgewählten Originaldateien werden nicht verändert. Die zuletzt ausgewählte URI und Seitenzahl werden in den lokalen App-Einstellungen abgelegt.

## Projektstruktur

- `app/src/main/java/de/beispiel/pdfleser/MainActivity.java`: Dateiauswahl, Rendering, Navigation
- `app/src/main/java/de/beispiel/pdfleser/ZoomablePdfView.java`: Zoom und Anzeige
- `app/src/main/AndroidManifest.xml`: Android-App-Einstellungen
- `app/src/main/res/`: Design, Text und Symbol
- `app/build.gradle`: Android-Build-Konfiguration

## Geplante Erweiterungen (nicht enthalten)

Textsuche in OCR-PDFs, Lesezeichen, Dokumentbibliothek, EPUB und Wörterbücher/Glossar, Google Drive-Synchronisierung.
